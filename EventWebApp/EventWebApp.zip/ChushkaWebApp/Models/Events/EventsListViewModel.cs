﻿namespace EventWebApp.Models.Events
{
    public class EventsListViewModel
    {
        public EventViewModel[] Events { get;  set; }
    }
}

