﻿namespace ChushkaWebApp.Models.Products
{
    public class ProductsListViewModel
    {
        public ProductViewModel[] Products { get; set; }
    }
}
